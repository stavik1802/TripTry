# app/server.py
import os
from typing import Optional, Dict, Any, List
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from dotenv import load_dotenv

# Load .env so MONGODB_* are available when running locally
load_dotenv()

# ---- your existing imports (agents, system, tools) ----
from app.agents.advanced_multi_agent_system import AdvancedMultiAgentSystem  # noqa: E402

# NEW: Mongo store helper
from app.storage.mongo_store import MongoStore  # noqa: E402

# ------------------------------------------------------------------------------
# FastAPI app
# ------------------------------------------------------------------------------
app = FastAPI(title="TripPlanner Multi-Agent Backend", version="1.1.0")

# ------------------------------------------------------------------------------
# CORS
# ------------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",   # Vite (default)
        "http://127.0.0.1:5173",
        "http://localhost:3000",   # React default
        "http://localhost:4173",   # Vite preview
        "http://localhost",        # Production frontend (adjust in prod)
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ------------------------------------------------------------------------------
# System init
# ------------------------------------------------------------------------------
SLA_SECONDS = int(os.getenv("SLA_SECONDS", "30"))
system = AdvancedMultiAgentSystem(sla_seconds=SLA_SECONDS)

# Mongo store (runs collection)
store = MongoStore()

# ------------------------------------------------------------------------------
# Models
# ------------------------------------------------------------------------------
class ProcessRequest(BaseModel):
    user_request: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None  # For continuing conversations

class ProcessResponse(BaseModel):
    status: str
    response: Dict[str, Any]
    session_id: Optional[str] = None
    agents_used: Optional[List[str]] = None
    learning_insights: Optional[Dict[str, Any]] = None

# ------------------------------------------------------------------------------
# Static files and frontend serving
# ------------------------------------------------------------------------------
# Check if we're in production (EB) and serve static files
if os.getenv("ENVIRONMENT") == "production":
    # Mount static files
    static_path = Path(__file__).parent.parent.parent / "trip_ui" / "dist"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
        
        # Serve React app for all non-API routes
        @app.get("/{full_path:path}")
        def serve_react_app(full_path: str):
            # Don't serve React app for API routes
            if full_path.startswith(("api/", "process", "health", "_debug")):
                raise HTTPException(status_code=404, detail="Not found")
            
            # Serve index.html for all other routes (React Router)
            index_file = static_path / "index.html"
            if index_file.exists():
                return FileResponse(str(index_file))
            else:
                return {"message": "Frontend not built. Please run build_frontend.sh"}

# ------------------------------------------------------------------------------
# Basic routes
# ------------------------------------------------------------------------------
@app.get("/")
def root():
    if os.getenv("ENVIRONMENT") == "production":
        # In production, serve the React app
        index_file = Path(__file__).parent.parent.parent / "trip_ui" / "dist" / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
    return {"message": "TripPlanner backend is alive."}

@app.get("/health")
def health():
    return {"ok": True, "time": datetime.utcnow().isoformat() + "Z"}

# Optional debug counts for Mongo (safe if MemorySystem is present)
@app.get("/_debug/memory_counts")
def memory_counts():
    try:
        # Import lazily to avoid circular imports if any
        from app.agents.memory_system import MemorySystem  # type: ignore
        ms = MemorySystem()
        db = ms.db
        if not db:
            return {"memories": -1, "learning_metrics": -1, "user_preferences": -1}
        return {
            "memories": db.memories.count_documents({}),
            "learning_metrics": db.learning_metrics.count_documents({}),
            "user_preferences": db.user_preferences.count_documents({}),
        }
    except Exception as e:
        return {"error": str(e)}

# NEW: DB health probe that writes and reads a tiny doc
@app.get("/health/db")
def db_health():
    try:
        store.client.admin.command("ping")
        probe = {"_type": "health_probe", "ts": datetime.utcnow()}
        ins = store.runs.insert_one(probe)
        ok = store.runs.find_one({"_id": ins.inserted_id}, {"_id": 1}) is not None
        return {"ok": True, "read_back": ok}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# NEW: Quick list of recent runs for demos
@app.get("/runs/latest")
def runs_latest(limit: int = 10):
    try:
        items = store.latest(limit=limit)
        for it in items:
            it["_id"] = str(it["_id"])
        return {"ok": True, "items": items}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ------------------------------------------------------------------------------
# /process endpoint (patched to log to MongoDB)
# ------------------------------------------------------------------------------
@app.post("/process", response_model=ProcessResponse)
def process(req: ProcessRequest):
    """
    Accepts:
      {
        "user_request": "restaurant recommendations in NYC",
        "user_id": "stav",          # optional
        "session_id": "..."         # optional (continue a session)
      }

    Returns (example):
      {
        "status": "success",
        "response": { ... your agents' output ... },
        "session_id": "session_2025....",
        "agents_used": [...],
        "learning_insights": {...}
      }
    """
    # Normalize minimal context; you can enrich this if your system exposes more
    context = {
        "countries": [],
        "cities": [],
        "dates": {},
        "travelers": {},
        "preferences": {},
        "budget_caps": {},
        "target_currency": "USD",
    }
    intent = "plan_trip"  # set/replace with your interpreter intent if available

    # 1) Start a DB run
    session_id = req.session_id or req.user_id or "anonymous"
    run_id = store.start_run(
        session_id=session_id,
        user_query=req.user_request,
        intent=intent,
        context=context,
    )

    try:
        # 2) Call your existing pipeline
        result = system.process_request(
            user_request=req.user_request,
            user_id=req.user_id,
            session_id=req.session_id,
        )

        # OPTIONAL: if your pipeline returns per-agent payloads, log them here.
        # Example structure (adjust to your real keys):
        # if isinstance(result, dict):
        #     agents_map = result.get("response", {}).get("agents") or {}
        #     for agent_name, payload in agents_map.items():
        #         store.log_agent_output(run_id, agent_name, payload, step=f"{agent_name} done")

        # 3) Finalize the run with the final deliverable
        if isinstance(result, dict) and "response" in result:
            final_payload = result["response"]
        elif isinstance(result, dict):
            final_payload = result
        else:
            final_payload = {"raw": str(result)}

        store.finish_run(run_id, final=final_payload, status="success")
        return result  # FastAPI will validate against ProcessResponse

    except Exception as e:
        # 4) Mark failure in DB and bubble up
        store.finish_run(run_id, final={}, status="error", error=str(e))
        raise HTTPException(status_code=500, detail=f"Processing failed: {e}") from e
