"""
AWS Elastic Beanstalk Application Entry Point
This file exposes the FastAPI app for Gunicorn/Uvicorn.
"""

import os
import sys
from pathlib import Path

# Add the Backend directory to Python path
backend_path = Path(__file__).parent / "Backend"
sys.path.insert(0, str(backend_path))

# Import the FastAPI app from your backend
try:
    from app.server import app  # <-- change if your FastAPI instance is elsewhere
    print("✅ Successfully imported FastAPI app")

    # Expose FastAPI app for Gunicorn/Uvicorn
    application = app

    # Health check route (so EB GET / passes)
    @app.get("/")
    def health():
        return {"ok": True}

except ImportError as e:
    print(f"❌ Failed to import app.server: {e}")
    print(f"Current working directory: {os.getcwd()}")
    print(f"Python path: {sys.path}")
    raise

# Local dev only
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(application, host="0.0.0.0", port=port)
