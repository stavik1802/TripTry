# Advanced Multi-Agent System with LangGraph Integration (steps 1–4)
from typing import Any, Dict, Optional, List
from datetime import datetime
import os

from .agent_coordinator import AgentCoordinator
from .base_agent import AgentContext
from .memory_system import MemorySystem
from .learning_agent import LearningAgent

# robust imports for agent classes used during registration
from .planning_agent import PlanningAgent
try:
    from .research_agent import ResearchAgent
except Exception:
    from .reasearch_agent import ResearchAgent
from .budget_agent import BudgetAgent
from .gap_agent import GapAgent
from .output_agent import OutputAgent


class AdvancedMultiAgentSystem:
    """Advanced multi-agent system with full coordination, learning, and SLA-aware routing"""

    def __init__(self, sla_seconds: Optional[float] = None):
        self.coordinator = AgentCoordinator()

        # ⚠️ SECURITY: do NOT hardcode secrets here. Let MemorySystem read from env.
        # If your MemorySystem supports explicit params, keep them env-driven.
        mongo_uri = os.getenv("MONGODB_URI")
        db_name = os.getenv("MONGODB_DB", "agent_memory")

        # If MemorySystem requires, pass the env vars; else, let it auto-load.
        try:
            self.memory_system = MemorySystem(mongo_uri=mongo_uri, db_name=db_name)  # type: ignore[arg-type]
        except TypeError:
            # Back-compat: some versions may not take args
            self.memory_system = MemorySystem()  # type: ignore[call-arg]

        # Load memories if available
        try:
            self.memory_system.load_from_database()
        except Exception:
            # Non-fatal if memory DB is not reachable
            pass

        self.learning_agent = LearningAgent()
        self.session_id: Optional[str] = None
        self.current_state: Optional[Dict[str, Any]] = None
        self.sla_seconds = sla_seconds

        # Initialize and register agents
        self.agents = {
            "planning_agent": PlanningAgent(),
            "research_agent": ResearchAgent(),
            "budget_agent": BudgetAgent(),
            "gap_agent": GapAgent(),
            "output_agent": OutputAgent(),
            "learning_agent": self.learning_agent,
        }
        for agent_id, agent in self.agents.items():
            self.coordinator.register_agent(agent_id, agent)

        # Inject shared memory system if agents expose the attribute
        for agent in self.agents.values():
            if hasattr(agent, "memory_system"):
                agent.memory_system = self.memory_system  # type: ignore[attr-defined]

        print("[Advanced Multi-Agent System] Initialized with agents:",
              ", ".join(self.agents.keys()))

    def process_request(
        self,
        user_request: str,
        user_id: str = "anonymous",
        session_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Process a user request through the multi-agent LangGraph pipeline"""
        # Use provided session_id or create new one
        self.session_id = session_id or f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        print(f"[Advanced Multi-Agent System] Processing request: {user_request[:120]}...")

        try:
            # Retrieve conversation history for context
            conversation_history: List[Dict[str, Any]] = []
            if self.session_id:
                conversation_history = self.memory_system.get_conversation_history(
                    session_id=self.session_id, user_id=user_id, limit=5
                )

            # If no session history, get recent conversations for user
            if not conversation_history and user_id != "anonymous":
                recent_conversations = self.memory_system.get_recent_conversations(
                    user_id=user_id, hours_back=24, limit=3
                )
                conversation_history = recent_conversations

            # Create initial agent context with conversation history
            agent_context = AgentContext(
                session_id=self.session_id,
                user_request=user_request,
                conversation_history=conversation_history,
                shared_data={
                    "user_id": user_id,
                    "timestamp": datetime.now().isoformat(),
                    "sla_seconds": self.sla_seconds,
                    "is_follow_up": len(conversation_history) > 0,
                    **(context or {}),
                },
                goals=[],
                constraints={},
            )

            # Create initial LangGraph state
            initial_state = self.coordinator.create_initial_state(
                user_request=user_request,
                user_id=user_id,
                context=agent_context,
            )
            # Pass SLA to state (if provided)
            if self.sla_seconds:
                initial_state["sla_seconds"] = self.sla_seconds

            # Build and run the LangGraph
            graph = self.coordinator.build_coordination_graph()
            final_state: Dict[str, Any] = graph.invoke(initial_state)
            self.current_state = final_state

            # Extract final response
            final_response = self._extract_final_response(final_state)

            # Store conversation turn for future follow-ups
            if final_response and self.session_id:
                conversation_turn = len(conversation_history) + 1
                self.memory_system.store_conversation_turn(
                    session_id=self.session_id,
                    user_id=user_id,
                    user_request=user_request,
                    agent_response=final_response,
                    conversation_turn=conversation_turn
                )
                print(f"[Advanced Multi-Agent System] Stored conversation turn {conversation_turn} for session {self.session_id}")

            # Learn from the interaction
            self._learn_from_session(user_id, user_request, final_response)

            # === NEW: Logging context for Mongo runs (server will persist it) ===
            logging_context = self._build_logging_context(
                user_id=user_id,
                agent_context=agent_context,
                final_state=final_state,
                final_response=final_response,
            )

            # Keep your existing return shape; add a "logging" section for the server
            return {
                "status": "success",
                "response": final_response,
                "session_id": self.session_id,
                "agents_used": list(self.agents.keys()),
                "learning_insights": self.learning_agent.get_learning_insights(),
                "logging": {
                    "context": logging_context,   # server uses this to fill Mongo 'context'
                    "agents": {},                 # placeholder; can be filled later if you emit per-agent payloads
                },
            }

        except Exception as e:
            print(f"[Advanced Multi-Agent System] Error: {e}")
            return {
                "status": "error",
                "error": str(e),
                "session_id": self.session_id,
                "logging": {
                    "context": {
                        "session_id": self.session_id,
                        "user_id": user_id,
                        "error": str(e),
                    },
                    "agents": {},
                },
            }

    def _extract_final_response(self, final_state: Dict[str, Any]) -> Dict[str, Any]:
        """Extract the final response from the final LangGraph state"""
        if isinstance(final_state, dict) and "final_response" in final_state:
            return final_state["final_response"] or {"message": "No response generated"}
        return {"message": "No response generated"}

    def _learn_from_session(self, user_id: str, user_request: str, response: Dict[str, Any]):
        """Learn from the session"""
        # Store session memory
        self.memory_system.store_memory(
            agent_id="system",
            memory_type="episodic",
            content={
                "user_id": user_id,
                "user_request": user_request,
                "response": response,
                "session_id": self.session_id,
            },
            importance=0.8,
            tags=["session", "user_interaction", user_id],
        )

        # Learn user preferences (best-effort if present)
        if isinstance(response, dict) and "preferences" in response:
            for pref_type, pref_value in response["preferences"].items():
                self.memory_system.learn_user_preference(
                    user_id=user_id,
                    preference_type=pref_type,
                    preference_value=pref_value,
                    confidence=0.7,
                    session_id=self.session_id,
                )

    def get_agent_status(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get status of agents"""
        if agent_id:
            if agent_id in self.agents:
                agent = self.agents[agent_id]
                return {
                    "agent_id": agent_id,
                    "status": agent.status,
                    "capabilities": getattr(agent, "capabilities", []),
                    "performance": agent.get_performance_metrics()
                    if hasattr(agent, "get_performance_metrics")
                    else {},
                }
            else:
                return {"error": f"Agent {agent_id} not found"}

        # Return all agent statuses
        return {
            agent_id: {
                "status": agent.status,
                "capabilities": getattr(agent, "capabilities", []),
                "performance": agent.get_performance_metrics()
                if hasattr(agent, "get_performance_metrics")
                else {},
            }
            for agent_id, agent in self.agents.items()
        }

    def get_system_insights(self) -> Dict[str, Any]:
        """Get comprehensive system insights"""
        return {
            "total_agents": len(self.agents),
            "active_agents": len([a for a in self.agents.values() if a.status == "working"]),
            "memory_stats": self._get_memory_stats(),
            "learning_metrics": self.learning_agent.get_performance_insights("learning_agent"),
            "coordination_protocols": len(self.coordinator.communication_protocols),
        }

    def _get_memory_stats(self) -> Dict[str, Any]:
        """Get memory system statistics (placeholder)"""
        return {
            "total_memories": "N/A",
            "active_learning": True,
            "consolidation_status": "operational",
        }

    def reset_system(self):
        """Reset the system state"""
        self.session_id = None
        self.current_state = None

    # ---------- NEW HELPERS FOR LOGGING ----------

    def _build_logging_context(
        self,
        *,
        user_id: str,
        agent_context: AgentContext,
        final_state: Dict[str, Any],
        final_response: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Try to extract structured trip context (countries, cities, dates, travelers, preferences)
        from either the final_state or the final_response. Fall back to agent_context.
        """
        # Defaults
        ctx: Dict[str, Any] = {
            "session_id": self.session_id,
            "user_id": user_id,
            "is_follow_up": agent_context.shared_data.get("is_follow_up"),
            "timestamp": agent_context.shared_data.get("timestamp"),
            "target_currency": agent_context.shared_data.get("target_currency", "USD"),
        }

        # Probe common places where your pipeline might store structured fields.
        candidates = [
            final_state.get("final_response") if isinstance(final_state, dict) else None,
            final_state,
            final_response,
            agent_context.shared_data,
        ]

        # Helper to pull a key if present
        def pull(obj: Any, key: str, default):
            if isinstance(obj, dict) and key in obj:
                return obj[key]
            return default

        # Merge best-effort fields
        for src in candidates:
            if not isinstance(src, dict):
                continue
            if "countries" not in ctx:
                ctx["countries"] = pull(src, "countries", [])
            if "cities" not in ctx:
                ctx["cities"] = pull(src, "cities", [])
            if "dates" not in ctx:
                ctx["dates"] = pull(src, "dates", {})
            if "travelers" not in ctx:
                ctx["travelers"] = pull(src, "travelers", {})
            if "preferences" not in ctx:
                ctx["preferences"] = pull(src, "preferences", {})
            if "budget_caps" not in ctx:
                ctx["budget_caps"] = pull(src, "budget_caps", {})

        # Final defaults
        ctx.setdefault("countries", [])
        ctx.setdefault("cities", [])
        ctx.setdefault("dates", {})
        ctx.setdefault("travelers", {})
        ctx.setdefault("preferences", {})
        ctx.setdefault("budget_caps", {})

        return ctx
