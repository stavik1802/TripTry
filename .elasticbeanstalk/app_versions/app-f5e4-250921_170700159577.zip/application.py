"""
AWS Elastic Beanstalk Application Entry Point
This file serves as the main entry point for the TripPlanner application on EB.
"""

import os
import sys
from pathlib import Path

# Add the Backend directory to Python path
backend_path = Path(__file__).parent / "Backend"
sys.path.insert(0, str(backend_path))

# Import the FastAPI app from the backend
try:
    from app.server import app
except ImportError as e:
    print(f"Failed to import app.server: {e}")
    print(f"Current working directory: {os.getcwd()}")
    print(f"Python path: {sys.path}")
    raise

# This is the WSGI application that EB will use
application = app

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)

