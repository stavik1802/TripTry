"""
AWS Elastic Beanstalk Application Entry Point
This file exposes the FastAPI app for Gunicorn/Uvicorn.
"""

import os
import sys
from pathlib import Path

# Add the Backend directory to Python path
backend_path = Path(__file__).resolve().parent / "Backend"
sys.path.insert(0, str(backend_path))

try:
    # Import FastAPI app from Backend/app/server.py
    from app.server import app
    print("✅ Successfully imported FastAPI app")

    # Expose ASGI app for Gunicorn in Procfile (application:application)
    application = app

    # Simple health route so EB health checks succeed even without UI
    @app.get("/_health")
    def _health():
        return {"ok": True}

except Exception as e:
    print(f"❌ Failed to import app.server: {e}")
    print(f"CWD: {os.getcwd()}")
    print(f"PYTHONPATH: {sys.path}")
    raise

# Local dev convenience: `python application.py`
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(application, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
