"""
Elastic Beanstalk entrypoint that *composes* the FastAPI app.
It guarantees a working /health and includes all routes from Backend/app/server.py
"""

import sys
from pathlib import Path
from fastapi import FastAPI

# Make Backend importable
backend_path = Path(__file__).parent / "Backend"
sys.path.insert(0, str(backend_path))

# Import your real app (ensure Backend/app/__init__.py exists)
from app.server import app as server_app  # noqa: E402

# Compose: create the EB-facing app and include all routes from server_app
application = FastAPI(title="TripPlanner (EB)")
application.include_router(server_app.router)

# Guaranteed health route (even if server_app changes)
@application.get("/health")
def health():
    return {"ok": True}
